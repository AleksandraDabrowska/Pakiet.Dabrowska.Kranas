#'Wartosc wyrazona w krolikach
#'
#'@docType data
#'@name wartosc_w_krolikach
#'@format wektor 7 elementowy
NULL

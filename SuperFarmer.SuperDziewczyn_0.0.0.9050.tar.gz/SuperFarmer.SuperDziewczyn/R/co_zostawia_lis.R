#'Co po ataku maksymalnie zostawia lis w stadzie gracza
#'
#'@docType data
#'@name co_zostawia_lis
#'@format nazwany wektor 7 elementowy
NULL

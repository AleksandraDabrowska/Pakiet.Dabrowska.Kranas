#'Maksymalne wartosci zwierzat w stadzie
#'
#'@docType data
#'@name stado_max
#'@format wektor 7 elementowy
NULL

#'Warunki wygranej
#'
#'@docType data
#'@name warunek_wygranej
#'@format wektor 7 elementowy
NULL

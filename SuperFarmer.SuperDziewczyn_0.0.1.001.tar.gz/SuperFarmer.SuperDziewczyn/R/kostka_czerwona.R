#'Zwierzeta na kostce czerwonej
#'
#'@docType data
#'@name kostka_czerwona
#'@format wektor 12 elementowy
NULL

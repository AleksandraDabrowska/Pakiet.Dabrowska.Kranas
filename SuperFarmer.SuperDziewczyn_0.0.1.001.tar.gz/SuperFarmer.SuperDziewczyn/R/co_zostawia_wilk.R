#'Co po ataku maksymalnie zostawia wilk w stadzie gracza
#'
#'@docType data
#'@name co_zostawia_wilk
#'@format nazwany wektor 7 elementowy
NULL

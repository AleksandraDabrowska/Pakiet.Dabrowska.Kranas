library(testthat)
library(SuperFarmer.SuperDziewczyn)

test_check("SuperFarmer.SuperDziewczyn")

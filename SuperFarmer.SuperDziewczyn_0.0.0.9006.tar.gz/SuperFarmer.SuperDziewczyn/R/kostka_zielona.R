#'Zwierzeta na kostce zielonej
#'
#'@docType data
#'@name kostka_zielona
#'@format wektor 12 elementowy
NULL
